/*
 * C API for the SDR board version ##VERSION##
 *
 * Copyright (C) 2014-2025 Amarisoft
 */
#ifndef SDR_LIB_H
#define SDR_LIB_H

#include <inttypes.h>
#include <stdarg.h>
#include <stddef.h>

#include "flags.h"

//#define SDR_MAX_CHANNELS 16
//#define SDR_MAX_RF_PORTS SDR_MAX_CHANNELS

/* Allow up to 16 SDR100 boards (2 SDR each) */
//#define MULTI_SDR_MAX 32

typedef enum {
    SDR_SAMPLE_FMT_CF32, /* complex float32 */
} SDRSampleFormatEnum;

typedef enum {
    SDR_SYNC_NONE, /* no time synchronisation */
    SDR_SYNC_INTERNAL, /* sync on internal PPS */
    SDR_SYNC_GPS, /* use built-in GPS */
    SDR_SYNC_EXTERNAL, /* use external sync (from PPS input on board) */
    SDR_SYNC_RESERVED1,
#ifdef USE_AD937x
    SDR_SYNC_EXTERNAL_4G, /* use ext clock and sync from 4G board (debug only) */
#else
    SDR_SYNC_RESERVED2,
#endif
    SDR_SYNC_EXTERNAL_50, /* use external sync (from PPS input on board) with 50 ohms */
} SDRSyncSourceEnum;

typedef enum {
    SDR_CLOCK_INTERNAL,   /* internal clock, using PPS to correct it */
    SDR_CLOCK_EXTERNAL,   /* external clock (from clock input on board) */
    SDR_CLOCK_EXT_10MHZ,  /* external clock from 10MHZ SMA on SDR100V2 */
} SDRClockSourceEnum;

typedef enum {
    SDR_SYNC_MODE_CABLE,     /* default: cables for inter SDR boards synchro */
    SDR_SYNC_MODE_ALL,       /* All SDR boards have their own sync and clock */
    SDR_SYNC_MODE_PCIE,      /* use PCIe for inter board synchro */
} SDRSyncModeEnum;

/* For SDR100V2 SMA connectors */
typedef enum {
    SDR_SMA_SYNC_MODE_INPUT,     /* SMA PPS is input */
    SDR_SMA_SYNC_MODE_OUTPUT,    /* SMA PPS is output */
} SDRSMASyncModeEnum;
    
typedef enum {
    SDR_SMA_CLOCK_MODE_IDLE,     /* SMA 10MHz is input idle */
    SDR_SMA_CLOCK_MODE_INPUT,    /* SMA 10MHz is input active (PPS ext) */
    SDR_SMA_CLOCK_MODE_OUTPUT,   /* SMA 10MHz is output */
    SDR_SMA_CLOCK_MODE_INPUT_50,  /* SMA 10MHZ is input with 50 ohms impedance */
} SDRSMAClockModeEnum;

typedef enum {
    SDR_INTERFACE_RF, /* RF interface */
#ifdef USE_CPRI
    SDR_INTERFACE_CPRI, /* CPRI interface */
    SDR_INTERFACE_ETH, /* Ethernet interface */
#endif
} SDRInterfaceEnum;

typedef enum {
    SDR_RF_NONE,
    SDR_RF_AD9361,
#ifdef USE_AD937x
    SDR_RF_AD937x,
#endif
#ifdef USE_CPRI
    SDR_CPRI,
#endif
} SDRRFType;

#ifdef USE_CPRI

#define CPRI_MAX_RF_PORTS 4         /* Max RF ports per CPRI link */
#define CPRI_PORT_MAX_CHANNEL 4     /* Max channel per port on CPRI link */

#define CPRI_MAX_CHANNEL (CPRI_MAX_RF_PORTS * CPRI_PORT_MAX_CHANNEL)

typedef struct {
    int locked;
    float rtt_us;
    int rx_bfn, rx_hfn;
    int tx_bfn, tx_hfn;
} CPRI_status;
    
typedef enum {
    SDR_CPRI_SPEED_UNSUPPORTED,
    SDR_CPRI_SPEED_614_4MBPS,      /* link rate 1 */
    SDR_CPRI_SPEED_1228_8MBPS,     /* link rate 2 */
    SDR_CPRI_SPEED_2457_6MBPS,     /* link rate 3 */
    SDR_CPRI_SPEED_3072_0MBPS,     /* link rate 4 */
    SDR_CPRI_SPEED_4915_2MBPS,     /* link rate 5 */
    SDR_CPRI_SPEED_6144_0MBPS,     /* link rate 6 */
    SDR_CPRI_SPEED_9830_4MBPS,     /* link rate 7 */
    SDR_CPRI_SPEED_8110_08MBPS,    /* link rate 7A */
    SDR_CPRI_SPEED_10137_6MBPS,    /* link rate 8 */
    SDR_CPRI_SPEED_12165_12MBPS,   /* link rate 9 */
    SDR_CPRI_SPEED_24330_24MBPS,   /* link rate 10 */
    
} SDRCPRISpeedEnum;
/* returns an enum */
SDRCPRISpeedEnum cpri_speed_from_speed_mult(int speed_mult, int coding_64_66);
SDRCPRISpeedEnum cpri_speed_from_option(const char *option);
/* return CPRI line rate as a string */
const char * cpri_option_from_speed(SDRCPRISpeedEnum cpri_speed);
int cpri_speed_mult_from_option(const char *option, int *pcoding);

/* returns a PHY speed (as in kernel/flags.h) to write in FPGA register */
int cpri_speed_mult_to_phy_speed(int cpri_speed_mult, int coding_64_66);


typedef enum {
    SDR_CPRI_MAPPING_STANDARD,
    SDR_CPRI_MAPPING_HW,
    SDR_CPRI_MAPPING_SPREAD,
    SDR_CPRI_MAPPING_HW_SPREAD,
    SDR_CPRI_MAPPING_BF1,
    SDR_CPRI_MAPPING_RX_EXP,
} SDRCPRIMappingEnum;

typedef enum {
    SDR_CPRI_EQ_MODE_LPM,
    SDR_CPRI_EQ_MODE_DFE,
} SDRCPRIEqModeEnum;

/* CPRI hook API */
#define CPRI_HOOK_VERSION   3

typedef struct CPRIHookState CPRIHookState;

struct CPRIHookState {
    /* API version */
    int version;

    /* Filled by driver, do not modify it */
    int speed_mult; /* CPRI line rate multiplier */
    const char *device;
    const char *user_data;

    void *app_opaque;
    void (*set_tx_state)(void *app_opaque, int on);

    /* Use K27.7 for vendor specific cata
     * Must be call from tx callback
     * size = 0 => disable
     * size < 1 => enable using full vendor specific data
     * size > 0 => define how many control words will be affected
     * When set, this parameter will be applied to all hyperframes
     * until next cal to this API
     */
    void (*set_vendor_K_character)(void *app_opaque, int size);

    void *reserved[29];

    /* Filled by shared library */
    void *opaque;

    /* subch_buf size is 256 * speed_mult
     * hfr_buf size is 256 * speed_mult * 16
     */
    void (*rx)(CPRIHookState *chs, const uint8_t *subch_buf, const uint8_t *hfr_buf, int valid);
    void (*tx)(CPRIHookState *chs, uint8_t *buf, int hfr /* 0: subch_buf, 1: hfr_buf */);

    void (*terminate)(CPRIHookState *chs);

    /* Reserved for further usage */
    void *reserved2[128];
};

int cpri_hook_init(CPRIHookState *s);

#endif

typedef enum {
    SDR_RX_ANTENNA_RX, /* use separate TX and RX connectors (default) */
    SDR_RX_ANTENNA_TX_RX, /* use same connector for TX and RX (TDD only) */
} SDRRXAntennaEnum;

/* hardware sample format */
typedef enum {
    SDR_SAMPLE_HW_FMT_AUTO, /* choose best format fitting the bandwidth */
    SDR_SAMPLE_HW_FMT_CI16, /* complex integer 16 bit */
    SDR_SAMPLE_HW_FMT_CF8, /* complex float 8 bit */
    SDR_SAMPLE_HW_FMT_BF2, /* compressed Block Float (9 bits out for 16 bits in) */
    
    SDR_SAMPLE_HW_FMT_LAST, /* terminator, keep at end of enum */
} SDRSampleHWFormatEnum;

typedef enum {
    SDR_ARM_CACHE_STD,      /* Std Kernel space (dma_sync_single_for_cpu/dma_sync_single_for_device) */
    SDR_ARM_CACHE_USER,     /* User space DVIC */
    SDR_ARM_CACHE_NONE,     /* none */
    SDR_ARM_CACHE_ZONE,     /* User space, one zone at a time */
} SDRARMCacheMode;

/* Srtucture with SDR device specific rf_driver parameters */
typedef struct {

    int gpio0_source, gpio1_source; /* signal source fo GPIO0/GPIO1 (TP3/TP4) */
    
    int dts_polarity;  /* SDR100 DTS polarity for TDD external switch */
    float pps_extra_delay;  /* delay added between SDR PPS input and frame start in us */

    float fifo_rx_time, fifo_tx_time; /* manual setting for FPGA RX FIFO in us */
    float fifo_rx_ratio, fifo_tx_ratio; /* manual setting to correct FPGA FIFO size */
    
    int rf_ports_max; /* Maximum RF ports allowed on device */

    int jesd_mode;     /* for testing */
#define JESD_4LANES  0
#define JESD_2LANES  1
#define JESD_TX307   2
    
#ifdef USE_CPRI
    SDRCPRISpeedEnum cpri_speed;
    SDRCPRIMappingEnum cpri_mapping;
    SDRCPRIEqModeEnum cpri_eq_mode;
    int fast_cm_pointer;
    char *vss_string;
    float cpri_tx_delay;
    float cpri_rx_delay;
    float cpri_tx_dbm;
    float cpri_rx_dbm;
    char *ifname;
    char *tx_subch_dump_filename;
    char *rx_subch_dump_filename;
    int eth_preamble_size;
    int offset_per_channel[CPRI_MAX_CHANNEL];
    const char *cpri_hook_so;
    const char *cpri_hook_user_data;
    int cpri_raw_rx;
    int cpri_raw_tx;
    int cpri_debug;
    int cpri_slave;
    uint8_t cpri_lock_frames; /* 0: default, else between 2 and 64 */
#endif
    int agc_flags;
    float agc_max_gain;
    float agc_min_gain;

    uint32_t special_flags;
#define SP_FLAG_TX_TDD_MOD      0x01    /* switch TX PA on TDD */
#define SP_FLAG_NO_INITMSG      0x02    /* do not print SDR init message */
#define SP_FLAG_SAFE_TX_GAIN    0x04    /* Limit tx_gain to prevent low MER */
#define SP_FLAG_RAW_TX_MODE     0x08    /* Do not adjust txgain for equal power on 4 channels */

    
    
} SpecialStartParams;

/* Check TRXDriverParams2 struct in trx_driver.h) */
typedef struct {
    SDRSyncSourceEnum sync_source;
    SDRClockSourceEnum clock_source;
    SDRSyncModeEnum sync_mode;           /* inter board sync mode */

    /* the sample rate (=sample_rate_num/sample_rate_den) for both
       transmit and receive. One by rf port */
    int64_t *sample_rate_num;
    int64_t *sample_rate_den;
    /* user sample format */
    SDRSampleFormatEnum rx_sample_fmt;
    SDRSampleFormatEnum tx_sample_fmt;
    /* hardware sample format (should be device specific ???) */
    SDRSampleHWFormatEnum rx_sample_hw_fmt;
    SDRSampleHWFormatEnum tx_sample_hw_fmt;
    /* number of RX channels (=RX antennas) */
    int rx_channel_count;
    /* number of TX channels (=TX antennas) */
    int tx_channel_count;
    /* RX center frequency in Hz for each channel */
    int64_t *rx_freq;
    /* TX center frequency in Hz for each channel */
    int64_t *tx_freq;
    /* initial rx_gain for each channel, same unit as trx_set_rx_gain_func() */
    double *rx_gain;
    /* initial tx_gain for each channel, same unit as trx_set_tx_gain_func() */
    double *tx_gain;
    /* RX bandwidth, in Hz for each channel */
    int *rx_bandwidth;
    /* TX bandwidth, in Hz for each channel */
    int *tx_bandwidth;
    /* RX antenna selection */
    SDRRXAntennaEnum *rx_antenna;

    /* Number of TX/RX ports.
       A separate msdr_write() must be done for each TX port.
       Each TX port can have a different TDD configuration.
       A separate msdr_read() must be done for each RX port.
     */
    int rf_port_count;
    /* Array of rf_port_count elements containing the number of
       channels per TX/RX port. Their sum must be equal to
       tx_channel_count/rx_channel_count. */
    int *tx_port_channel_count;
    int *rx_port_channel_count;

    /* For each rf_port, can add a vector de swap logical rx channels
     * between physical rx ports */
    int **rf_port_rx_mapping;

    /* if != 0, set a custom DMA buffer configuration. Otherwise the
       default is 150 buffers per 10 ms */
    int dma_buffer_count;
    int dma_buffer_len; /* in samples */

    int rx_latency; /* in us (0 means default value: 1HFR ~ 67us) */
    
    /* following params should be device specific ? */
    const char *config_script;
    const char *config_script_params;
    
    int tx_delay;
    int rx_delay;
    
    /* Parameters defined for each SDR device (CPRI and others) */
    int sdr_count;
    SpecialStartParams *spt;

    /* From TRXDriverParams2 */
    uint8_t flags1;
#define P_FLAGS1_TX_ABS_POWER            (1 << 0)   /* tx_gain array contain target abs power in dbm */
#define P_FLAGS1_RX_ANTENNA_RX  (1 << 1)   /* RX on RX connector */
    uint8_t flags2;
    uint8_t flags3;

    SDRARMCacheMode arm_cache_mode;

} SDRStartParams;

typedef struct {
    /* Number of times the data was sent too late by the application. */
    int64_t tx_underflow_count;
    /* Number of times the receive FIFO overflowed. */
    int64_t rx_overflow_count;
} SDRStats;

/* Structure used for set_agc and get_agc */
typedef struct {
#define TRX_AGC_OFF            0x00
#define TRX_AGC_ON             0x01
#define TRX_AGC_USE_DB         0x02    /* Use high_db and low_db values from struct */
#define TRX_AGC_USE_MAX_GAIN   0x04    /* Use max_gain from struct */
#define TRX_AGC_USE_MIN_GAIN   0x08    /* Use min_gain from struct */

    int flags;
    
    float high_db;
    float low_db;

    float max_gain;
    float min_gain;
} SDRAGCParams;

typedef struct MultiSDRState MultiSDRState;

/* see also trx_sdr/trx_driver.h */
typedef struct {
    int64_t gps_time;   /* in seconds since 1 Jan 1970, UTC, -1 if error */
    double latitude;    /* in degres, positive for 'N', negative for 'S' [-90 .. 90] */
    double longitude;   /* in degres, positive for 'E', negative for 'W' [-180 .. 180] */
    double height;      /* height in meter */
    int nb_sats;        /* number of sats [0..12] */
    double geoid_sep;   /* difference between ellipsoid and mean sea level (m) */

    int64_t info_ms;    /* local time of information in ms (used internally to adjust gps_time) */
} GPSInfo;

/*
 * 'args' is a string of comma separated arguments. Available
 * arguments:
 *
 * 'devN=value' : set the device name for the N-th board. 'dev0' is
 * assumed to have the master clock. The other boards must be
 * connected so that they are synchronized to the master.
 */
MultiSDRState *msdr_open(const char *args);
int msdr_get_sdrcount(MultiSDRState *s);
void msdr_set_default_start_params(MultiSDRState *s, SDRStartParams *p, size_t p_size,
                                   int tx_count, int rx_count, int port_count);
void msdr_set_default_special_start_params(SpecialStartParams *spt);
void msdr_set_default_rf_port_rx_mapping(MultiSDRState *s, SDRStartParams *p);

void msdr_release_start_params(SDRStartParams *p, size_t p_size);
int msdr_set_start_params(MultiSDRState *s, const SDRStartParams *p, size_t p_size);
void msdr_set_special_flags(MultiSDRState *s, SDRStartParams *p, int set_flags, int clear_flags);
int msdr_start(MultiSDRState *s);
int msdr_start1(MultiSDRState *s, const SDRStartParams *p, size_t p_size);
int msdr_stop(MultiSDRState *s);
int msdr_set_freq_fast(MultiSDRState *s, int64_t rxfreq, int64_t txfreq);
int msdr_get_mt_status(MultiSDRState *s, int *pmt_write, int *pmt_read, int rf_port_index);

int msdr_set_tx_gain(MultiSDRState *s, int channel, double gain);
int msdr_set_rx_gain(MultiSDRState *s, int channel, double gain);
double msdr_get_tx_gain(MultiSDRState *s, int channel);
double msdr_get_rx_gain(MultiSDRState *s, int channel);
double msdr_get_abs_tx_power(MultiSDRState *s, int channel);
double msdr_get_abs_rx_power(MultiSDRState *s, int channel);
int msdr_set_abs_tx_power(MultiSDRState *s, int channel, double power);
int msdr_get_tx_gain_from_power(MultiSDRState *s, int channel, double *p_gain, double power);
int msdr_set_agc(MultiSDRState *s, int channel, SDRAGCParams *p);
int msdr_get_agc(MultiSDRState *s, int channel, SDRAGCParams *p);
int msdr_get_numa_nodes(MultiSDRState *s, uint64_t *numa_nodes);
const int* msdr_get_sample_rate_nums(MultiSDRState *s);
SDRInterfaceEnum msdr_get_interface_type(MultiSDRState *s);
SDRRFType msdr_get_rf_type(MultiSDRState *s);
int64_t msdr_get_tai_time(MultiSDRState *s, int *ptai_offset);
int msdr_get_gps_info(MultiSDRState *s, GPSInfo *gps);
#ifdef USE_CPRI
int msdr_get_cpri_status(MultiSDRState *s, int channel, CPRI_status *tcs);
SDRCPRISpeedEnum cpri_speed_mult_to_enum(int cpri_speed_mult);
int msdr_set_cpri_rx_delay(MultiSDRState *s, int port_index, double rx_delay1);
int msdr_get_cpri_rx_delay(MultiSDRState *s, int port_index, double *prx_delay);
int msdr_set_cpri_tx_delay(MultiSDRState *s, int port_index, double tx_delay1);
int msdr_get_cpri_tx_delay(MultiSDRState *s, int port_index, double *ptx_delay);
#endif
int msdr_set_rfic_config(MultiSDRState *ms, int rfic_config);
int msdr_get_hw_bps(MultiSDRState *ms, int channel);


#define MSDR_ERROR_INVALID_PARAM    -1
#define MSDR_ERROR_TIMEOUT          -2
#define MSDR_ERROR_OVERTEMP         -3
#define MSDR_ERROR_NOT_SUPPORTED    -4
#define MSDR_ERROR_BAD_INTERFACE    -5
#define MSDR_ERROR_EARLY_TIMESTAMP  -6
#define MSDR_ERROR_LATE_TIMESTAMP   -7
#define MSDR_ERROR_BAD_ALIGNMENT    -8
#define MSDR_ERROR_INTERNAL_ERROR   -10
#define MSDR_ERROR_BAD_RF_PORT      -11


/* samples = NULL means to disable TX (TDD case). 'flags' is currently
   ignored. */
typedef struct {
    /* Out */
    int64_t cur_timestamp;
    int8_t underflow;
} MultiSDRWriteMetadata;

int msdr_write(MultiSDRState *s, int64_t timestamp,
               const void **samples, int count, int port_index,
               MultiSDRWriteMetadata *md);
void msdr_write_end(MultiSDRState *s, int64_t timestamp, int rf_port_index);

typedef struct {
    /* In */
    int timeout_ms;

    /* Out */
    int8_t overflow;
    int8_t agc_change;
} MultiSDRReadMetadata;

int msdr_read(MultiSDRState *s, int64_t *ptimestamp,
              void **samples, int count, int port_index, MultiSDRReadMetadata *md);
int msdr_read_at(MultiSDRState *s, int64_t timestamp, void **samples, int count,
                 int port_index, MultiSDRReadMetadata *md);
int msdr_read_timestamp(MultiSDRState *s, int64_t *ptimestamp,
                        int port_index, int timeout_ms);

void msdr_close(MultiSDRState *s);
int msdr_get_stats(MultiSDRState *s, SDRStats *m);

typedef void __attribute__ ((format (printf, 2, 3))) (*msdr_printf_cb)(void *opaque, const char *fmt, ... );
void msdr_dump_info(MultiSDRState *s, msdr_printf_cb cb, void *opaque);
double msdr_get_temp(MultiSDRState *s, int idx);
int msdr_clock_tune(MultiSDRState *ms, double offset);
double msdr_get_tx_gain_min_max(MultiSDRState *s, int channel, double *mingain, double *maxgain);
double msdr_get_rx_gain_min_max(MultiSDRState *s, int channel, double *mingain, double *maxgain);
int msdr_sma_set(MultiSDRState *s, SDRSMAClockModeEnum sma_clock, SDRSMASyncModeEnum sma_sync);
int msdr_sma_get(MultiSDRState *s, SDRSMAClockModeEnum *sma_clock, SDRSMASyncModeEnum *sma_sync);

/* Logs */
typedef enum {
    SDR_LOG_NONE,
    SDR_LOG_ERROR,
    SDR_LOG_WARN,
    SDR_LOG_INFO,
    SDR_LOG_DEBUG,
} SDRLogLevel;

typedef enum {
    SDR_LOG_DIR_UNKNOWN,
    SDR_LOG_TX,
    SDR_LOG_RX,
} SDRLogDir;

typedef struct {
    void *opaque;
    void (*log)(void *opaque, SDRLogLevel level, SDRLogDir dir, const char *fmt, va_list ap);
    int (*pthread_init)(void *opaque, const char *name);
    void (*pthread_terminate)(void *opaque);
#ifdef RT_PROFILER
    void (*rt_prof_event_start)(void *opaque, const char *fmt, ...);
    void (*rt_prof_event_stop)(void *opaque);
    void __attribute__ ((format (printf, 2, 3))) (*rt_prof_tag)(void *opaque, const char *fmt, ...);
    void __attribute__ ((format (printf, 2, 3))) (*rt_prof_pause)(void *opaque, const char *fmt, ...);
    void (*rt_prof_resume)(void *opaque);
#endif
} SDRCallbacks;

void msdr_set_callbacks(MultiSDRState *s, const SDRCallbacks *callbacks);

void msdr_set_log_level(MultiSDRState *s, SDRLogLevel level);

int64_t sdr_get_time_ms(void);
int64_t sdr_get_time_us(void);
int64_t sdr_get_time_ns(void);

/* msdr_write() and msdr_read() currently only accept complex 32 bit
   floating point samples. The following functions can be used to
   efficiently convert between complex 32 bit floating point and
   complex signed 16 bit integer samples. The parameter 'n' is the
   number of complex samples. */
void msdr_convert_cf32_to_ci16(int16_t *dst, const float *src, size_t n);
void msdr_convert_ci16_to_cf32(float *dst, const int16_t *src, size_t n);

typedef struct {
    int freq; /* MHz */
    float val;
} CalibPowerEntry;

float get_calib_power(const CalibPowerEntry *tab, int n, int freq);

#endif /* SDR_LIB_H */
