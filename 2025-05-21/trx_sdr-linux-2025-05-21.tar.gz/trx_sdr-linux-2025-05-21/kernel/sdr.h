/*
 * PCI SDR driver
 *
 * Copyright (C) 2014-2025 Amarisoft
 */
#ifndef _LINUX_SDR_H
#define _LINUX_SDR_H

#include <linux/types.h>

struct sdr_ioctl_mmap_info {
    __u64 reg_offset;
    __u64 reg_size;
    __u64 smem_offset;
    __u64 smem_size;
    __u32 dma_channel_count;
    __u32 numa_node;
    __u32 bus_num;
    __u32 dma_64;
};

struct sdr_ioctl_dma_ch_cnt {
    __u32 dma_channel_count;
};

/* For compatibility with old drivers */
struct sdr_ioctl_old_dma_info {
    __u32 dma_channel; /* DMA channel number */
    __u32 __reserved0;
    __u64 dma_tx_buf_offset;
    __u64 dma_tx_buf_size;
    __u64 dma_tx_buf_count;

    __u64 dma_rx_buf_offset;
    __u64 dma_rx_buf_size;
    __u64 dma_rx_buf_count;

    __u64 dma_smem_offset;
    __u64 dma_smem_size;
};


struct sdr_ioctl_dma_info {
    __u32 dma_channel; /* DMA channel number */
    __u32 __reserved0;
    __u64 dma_tx_buf_offset;
    __u64 dma_tx_buf_size;
    __u64 dma_tx_buf_count;

    __u64 dma_rx_buf_offset;
    __u64 dma_rx_buf_size;
    __u64 dma_rx_buf_count;

    __u64 dma_smem_offset;
    __u64 dma_smem_size;

    __u32 dma_base;
};

#define SDR_DMA_FLAGS_LOOPBACK (1 << 0) /* enable DMA loopback */
#define SDR_DMA_FLAGS_SYNC     (1 << 1) /* start on PPS */

struct sdr_ioctl_dma_start {
    __u32 dma_channel; /* DMA channel number */
    __u32 dma_flags; /* see SDR_DMA_FLAGS_x */
    __u32 tx_buf_count; /* number of TX buffers, must be <= dma_tx_buf_count, 0 if no TX */
    __u32 tx_buf_size; /* in bytes, must be <= dma_tx_buf_size. 0 if no TX */
    __u32 rx_buf_count; /* number of RX buffers, must be <= dma_rx_buf_count, 0 if no RX */
    __u32 rx_buf_size; /* in bytes, must be < dma_rx_buf_size. 0 if no RX */
};

struct sdr_ioctl_dma_stop {
    __u32 dma_channel; /* DMA channel number */
};

/* If tx_wait is true, wait until the current TX buffer number is
   different from tx_buf_num. If tx_wait is false, wait until the
   current RX buffer number is different from rx_buf_num. Return the
   last sent TX buffer number in tx_buf_num and the last received RX
   buffer number in rx_buf_num. */
struct sdr_ioctl_dma_wait {
    __u32 dma_channel; /* DMA channel number */
    __s32 timeout; /* in ms. Return -EAGAIN if timeout occured without event */
    __u32 tx_wait;
    __u32 tx_buf_num; /* read/write */
    __u32 rx_buf_num; /* read/write */
    __u16 tx_loop;
    __u16 rx_loop;
};

enum {
    SDR_SPI_TYPE_AD9361,
    SDR_SPI_TYPE_AD9528,
    SDR_SPI_TYPE_AD937x,
};

struct sdr_ioctl_spi_rw {
    __u8 spi_type; /* Check SDR_SPI_TYPE_XXX */
    __u8 is_write;
    __u16 addr;
    __u8 val;
};

struct sdr_ioctl_board_rw {
    __u32 addr;
    __u32 val;
    __u8 is_write;
    __u8 _reserved;
};

struct sdr_ioctl_flash_spi {
    int tx_len; /* nb of bits to write (8 to 40) */
    __u64 tx_data; /* 8 to 40 or 48 bits */
    __u64 rx_data; /* 40 bits */
};

struct sdr_ioctl_flash_page_program {
    __u8  cmd;        /* FLASH_PP or FLASH_PP_4B */
    __u8  mode4;      /* 1 if 4B address */
    __u16 reserved;
    __u32 page_addr;  /* 3 or 4 byte address */
    __u8 page_data[256];  /* 256 bytes to send (LSB first) */
};

struct sdr_ioctl_flash_page_read {
    __u8  cmd;        /* FLASH_READ or FLASH_READ_4B */
    __u8  mode4;      /* 1 if 4B address */
    __u16 reserved;
    __u32 page_addr;  /* 3 or 4 byte address */
    __u8 page_data[256];  /* 256 bytes to read (LSB first) */
};

struct sdr_ioctl_gps_write {
    int tx_buf_len;
    __u32 pad;
    __u64 tx_buf; /* pointer to buffer */
};

struct sdr_ioctl_gps_read {
    int rx_buf_max_len; /* maximum number of received bytes */
    int rx_buf_len; /* actual number of received bytes */
    __u64 rx_buf; /* pointer to buffer */
};

struct sdr_ioctl_sync_dma_buf {
    int dma_channel;
    int buf_num;
    int buf_prev;
    int mode;  /* O:RX  1:TX */
};

struct sdr_ioctl_cpri_speed {
    int dma_channel;
    int speed_mult;  /* 0 for 'free' */
};

typedef enum {
    SDR_SYNC_SOURCE_INTERNAL, /* use internal clock and PPS */
    SDR_SYNC_SOURCE_GPS, /* use built-in GPS */
    SDR_SYNC_SOURCE_EXTERNAL, /* use external PPS and clock (PREV) */
    SDR_SYNC_SOURCE_EXTERNAL_PPS, /* use internal clock and external PPS (UFL) */
    SDR_SYNC_SOURCE_CPRI, /* use sync from incoming CPRI (CPRI slave mode) */
    SDR_SYNC_SOURCE_EXTERNAL_CLOCK, /* use external clock and internal PPS */
    SDR_SYNC_SOURCE_RESET, /* force clock reinit */
    SDR_SYNC_SOURCE_PREV_PPS,  /* use internal clock and external PPS (PREV) for ext GPS cal */
    SDR_SYNC_SOURCE_EXTERNAL_4G,  /* use ext clock and ext PPS unmodulated: SDR5G slaved to SDR4G */
    SDR_SYNC_SOURCE_EXTERNAL_10MHZ,  /* use ext clock and ext PPS from SDR100V2 SMA */
    SDR_SYNC_SOURCE_EXTERNAL_PPS_50,  /* use internal clock and external PPS with 50 ohm impedance (CPRI40) */
    SDR_SYNC_SOURCE_PCIE,    /* use PCIE synchro (for logical SLAVE only) */
    SDR_SYNC_SOURCE_PREV_PPS_MOD,   /* use internal clock and external modulated PPS (PREV) */
} sdr_sync_source;

struct sdr_ioctl_sync_state {
    __u8 sync_source; /* see SDR_SYNC_SOURCE_ */
    __u8 pps_locked; /* 1 if the clock is locked on the PPS; 2 if GPS_PPS inactive (fallback from PPS_VCXO) */
                     /* 3 if waiting for GPS tuning to stabilize */
    __u8 clock_source; /* 0 = internal, 1 = external */
    __u8 clock_pll_locked; /* true if the RFIC/CPRI PLL clock is locked (this
                              is relevant when an external clock input is
                              used) */
    __u32 clock_freq;     /* clock frequency in Hz */
};

struct sdr_ioctl_status {
    __u32 sysid;
    __u32 rev;
    __u32 ad937x_base;   /* Base for CSR_AD937X_xxx_ADDR_REL registers */
    __u32 flags;
#define SDR_STATUS_AD9361          0x0001
#define SDR_STATUS_AD9371          0x0002
#define SDR_STATUS_AD9528          0x0004
#define SDR_STATUS_CDCM6208        0x0008
#define SDR_STATUS_SI5324          0x0010
#define SDR_STATUS_CPRI            0x0020
#define SDR_STATUS_MASTER          0x0040
    
#define SDR_STATUS_V2_MASTER_DMA   0x0080   /* for SDR100_V2 */
#define SDR_STATUS_V2_SLAVE_DMA    0x0100

#define SDR_STATUS_FLASH_4BYTES    0x0200  /* FPGA supports FLASH SPI 4 bytes mode */

#define SDR_STATUS_FP8             0x0400   /* FPGA supports 8bit codec algo */
#define SDR_STATUS_BF2             0x0800   /* FPGA supports BF2 codec */
    
#define SDR_STATUS_DMA_RX_HEADER   0x1000   /* FPGA has DMA RX headers */
#define SDR_STATUS_DMA_HEADER_V2   0x2000   /* FPGA has DMA V2 headers */
    
#define SDR_STATUS_CPRI_64B66B     0x4000   /* FPGA has CPRI 64/66 coding */

};

struct sdr_ioctl_pll {    /* set or get */
    uint16_t mode;          /* current mode */
    uint32_t freq;     /* 10MHz only for now */
    uint32_t flags;    /* PLL_IN_1K or PLL_IN_50R  */
};

enum {
    SMA_PLL_IDLE,
    SMA_PLL_IN,
    SMA_PLL_OUT,
};

#define PLL_IN_1K      0
#define PLL_IN_50R     1


struct sdr_ioctl_sma_pps {    /* set or get */
    uint16_t mode;     /* current mode */
    uint16_t flags;    /* not use for now */
};

enum {
    SMA_PPS_IN,
    SMA_PPS_OUT,
};

struct sdr_ioctl_sync_mem {
    uint32_t addr_lsb;
    uint32_t addr_msb;
    size_t  size;
};


#define SDR_IOCTL 'S'

#define SDR_IOCTL_GET_MMAP_INFO _IOR(SDR_IOCTL, 0, struct sdr_ioctl_mmap_info)
#define SDR_IOCTL_GET_DMA_INFO _IOWR(SDR_IOCTL, 13, struct sdr_ioctl_dma_info)
#define SDR_IOCTL_GET_OLD_DMA_INFO _IOWR(SDR_IOCTL, 13, struct sdr_ioctl_old_dma_info)

#define SDR_IOCTL_DMA_START _IOW(SDR_IOCTL, 1, struct sdr_ioctl_dma_start)
#define SDR_IOCTL_DMA_STOP  _IOW(SDR_IOCTL, 2, struct sdr_ioctl_dma_stop)
#define SDR_IOCTL_DMA_WAIT  _IOWR(SDR_IOCTL, 3, struct sdr_ioctl_dma_wait)

#define SDR_IOCTL_SPI_RW _IOWR(SDR_IOCTL, 4, struct sdr_ioctl_spi_rw)

#define SDR_IOCTL_SPI_RESET _IOR(SDR_IOCTL, 5, int)

/* FPGA flash SPI I/O (blocking call) */
#define SDR_IOCTL_FLASH_SPI _IOWR(SDR_IOCTL, 7, struct sdr_ioctl_flash_spi)

/* Write data to GPS UART (blocking call) */
#define SDR_IOCTL_GPS_WRITE _IOW(SDR_IOCTL, 8, struct sdr_ioctl_gps_write)

/* Enable or disable GPS UART reception */
#define SDR_IOCTL_GPS_RX_ENABLE _IOW(SDR_IOCTL, 9, int)

/* Read data from GPS (non blocking) */
#define SDR_IOCTL_GPS_READ _IOW(SDR_IOCTL, 10, struct sdr_ioctl_gps_read)

/* Set synchronisation source */
#define SDR_IOCTL_SET_SYNC_SOURCE _IO(SDR_IOCTL, 11)

/* Get synchronisation source */
#define SDR_IOCTL_GET_SYNC_STATE _IOR(SDR_IOCTL, 12, struct sdr_ioctl_sync_state)

/* SDR Board register Read/Write */
#define SDR_IOCTL_BOARD_RW _IOR(SDR_IOCTL, 13, struct sdr_ioctl_board_rw)
    
/* SDR Board Get DMA channel count */
#define SDR_IOCTL_GET_DMA_CH_CNT _IOR(SDR_IOCTL, 14, struct sdr_ioctl_dma_ch_cnt)

/* Only for SDR5G: Control Output state of SYSREF clock */
#define SDR_IOCTL_AD9371_SET_SYSREF _IOW(SDR_IOCTL, 15, int)

/* Set CPRI slave mode */
#define SDR_IOCTL_SET_CPRI_SLAVE _IO(SDR_IOCTL, 16)

/* Get CPRI slave mode */
#define SDR_IOCTL_GET_CPRI_SLAVE _IOR(SDR_IOCTL, 17, int)

/* Reserve DMA channel */
#define SDR_IOCTL_RESERVE_DMA_CH _IOR(SDR_IOCTL, 18, int)

/* Release DMA channel */
#define SDR_IOCTL_RELEASE_DMA_CH _IOR(SDR_IOCTL, 19, int)

/* Sync DMA buffer for ARM architecture */
#define SDR_IOCTL_SYNC_DMA_BUF _IOR(SDR_IOCTL, 20, struct sdr_ioctl_sync_dma_buf)

/* Select CPRI speed mult for specified DMA channel, return error if not compatible */
#define SDR_IOCTL_SET_CPRI_SPEED _IOR(SDR_IOCTL, 21, struct sdr_ioctl_cpri_speed)

/* Return Master status */
#define SDR_IOCTL_GET_STATUS _IOR(SDR_IOCTL, 22, struct sdr_ioctl_status)

/* Set PLL for SMA CLOCK (SDR100V2 only) */
#define SDR_IOCTL_SET_PLL _IOW(SDR_IOCTL, 23, struct sdr_ioctl_pll)

/* Get PLL for SMA clock(SDR100V2 only) */
#define SDR_IOCTL_GET_PLL _IOW(SDR_IOCTL, 24, struct sdr_ioctl_pll)

/* Set state for SMA PPS (SDR100V2 only) */
#define SDR_IOCTL_SET_SMA_PPS _IOW(SDR_IOCTL, 25, struct sdr_ioctl_sma_pps)

/* Set state for SMA PPS (SDR100V2 only) */
#define SDR_IOCTL_GET_SMA_PPS _IOW(SDR_IOCTL, 26, struct sdr_ioctl_sma_pps)

/* Send 256 bytes for Flash Page Program */
#define SDR_IOCTL_FLASH_PAGE_PROGRAM _IOW(SDR_IOCTL, 27, struct sdr_ioctl_flash_page_program)

/* Read 256 bytes from Flash */
#define SDR_IOCTL_FLASH_PAGE_READ _IOW(SDR_IOCTL, 28, struct sdr_ioctl_flash_page_read)

/* Read shared sync mem phys address */
#define SDR_IOCTL_GET_SYNC_MEM _IOR(SDR_IOCTL, 29, struct sdr_ioctl_sync_mem)

#endif /* _LINUX_SDR_H */
