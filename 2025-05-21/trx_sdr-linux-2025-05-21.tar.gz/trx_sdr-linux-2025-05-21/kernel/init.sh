#!/bin/bash
# Copyright (C) 2015-2025 Amarisoft
# SDR kernel driver initialization version 2025-05-21
# TODO: use udev instead


# Move to script directory
cd $(readlink -f $(dirname $0))

function Help
{
    echo "Usage:"
    echo "$0 [options]"
    echo "Initialize Amarisoft TRX sdr kernel driver"
    echo "options:"
    echo "  -c: force compilation"
    echo "  -f: force reload of module if already inserted"
    echo "  --dma32: force 32 bits DMA mode (persistent)"
    echo "  --no-dma32: revert 32 bits DMA mode"
    exit 1
}

DMA_FILE="${HOME}/.trx_sdr.dma32"
FORCE="n"
COMPILE="n"
while [ "$1" != "" ] ; do
    case "$1" in
    --force|-f)
        FORCE="y"
        ;;
    --compile|-c)
        COMPILE="y"
        ;;
    --dma32)
        touch $DMA_FILE
        ;;
    --no-dma32)
        rm -f $DMA_FILE
        ;;
    -h|--help)
        Help
        ;;
    *)
        echo "Invalid argument: $1"
        Help
        ;;
    esac
    shift
done

DMA64=$(grep "#define USE_DMA64" main.c)
if [ "${DMA64:0:2}" != "//" ] ; then
    if [ -e "$DMA_FILE" ] ; then
        echo "* Set DMA32 mode"
        perl -p -i -e "s/^#define USE_DMA64/\/\/#define USE_DMA64/" main.c
        COMPILE="y"
    fi
else
    if [ ! -e "$DMA_FILE" ] ; then
        echo "* Set DMA64 mode"
        perl -p -i -e "s/^\/\/#define USE_DMA64/#define USE_DMA64/" main.c
        COMPILE="y"
    else
        echo "* Use DMA32 mode"
    fi
fi

FOUND=$(lsmod | grep sdr)
if [ "$FOUND" != "" ] ; then
    if [ "$FORCE" = "y" -o "$COMPILE" = "y" ] ; then
        echo "* Remove module"
        rmmod sdr
    else
        echo "Module already installed"
        exit 0
    fi
fi

if [ "$COMPILE" = "y" ] ; then
    echo "* Recompile module"
    set -e
    make -s clean
    make -s
    set +e
fi

echo "* Install kernel module"
INS=$(insmod sdr.ko 2>&1)
if [ "$?" != "0" ] ; then
    ERR=$(echo $INS | sed -s "s/.*sdr.ko: //")
    case $ERR in
    'Invalid module format')
        set -e
        echo "Kernel may have changed, try to rebuild module"
        make -s clean
        make -s
        insmod sdr.ko
        set +e
        ;;
    'No such file or directory')
        set -e
        echo "Module not compiled"
        make -s
        insmod sdr.ko
        set +e
        ;;
    'Required key not available')
        echo "Can't insert kernel module, secure boot is probably enabled"
        echo "Please disable it from BIOS"
        exit 1
        ;;
    *)
        >&2 echo $INS
        exit 1
    esac
fi

DEV_MAX=$(grep -oP "#define SDR_MINOR_COUNT\s+\K\d+" main.c 2>/dev/null)
if [ "$DEV_MAX" = "" ] ; then DEV_MAX="16"; fi

mapping=""
major=$(awk '/ sdr$/{print $1}' /proc/devices)
if [ -e "/etc/sdr-mapping" ] ; then
    mapping=$(head -n 1 /etc/sdr-mapping)
    echo "* Use mapping: $mapping"
else
    mapping=$(seq 0 $(( $DEV_MAX - 1 )) )
fi

d=0
for i in $mapping ; do
    rm -f "/dev/sdr$d"
    if [[ $i -ge $DEV_MAX ]] ; then
        echo "Out of bound minor: $i" >&2
        exit 1
    fi
    mknod -m 666 /dev/sdr$d c $major $i
    {
        # Try to open device to check it exists
        exec 3< /dev/sdr$d
        if [ "$?" != "0" ] ; then
            rm /dev/sdr$d
            if [ -e "/etc/sdr-mapping" ] ; then
                echo "Warning, mapping error for /dev/sdr$i" >&2
            fi
        fi
        exec 3<&-
    } 2>/dev/null
    d=$(( $d + 1 ))
done
DEVLIST=$(ls /dev/sdr* 2>/dev/null | xargs -r echo)
if [ "$DEVLIST" = "" ] ; then
    echo "No device found"
else
    echo "Devices: $DEVLIST"
fi

