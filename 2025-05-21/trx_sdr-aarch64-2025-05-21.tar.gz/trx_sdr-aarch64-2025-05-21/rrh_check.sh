#!/bin/bash
# Copyright (C) 2015-2025 Amarisoft
# SDR board presence checker + init version 2025-05-21

set -e

CUR_DIR=$(pwd)
cd $(dirname $0)

FOUND=$(lsmod | grep sdr || echo "")
if [ "$FOUND" = "" ] ; then
    echo "Initialize SDR kernel module"
    cd kernel

    set +e
    ./init.sh
    RET="$?"
    set -e
    if [ "$RET" != "0" ] ; then
        echo "Error while initializing driver:" >&2
        dmesg | tail -n 5 >&2
        exit $RET
    fi

    cd ..
fi

declare -a DEVS
TEMP=""
OTS="n"

while [ "$1" != "" ] ; do
    case "$1" in
    --ots)
        #OTS="y"
        ;;
    --temp)
        TEMP="$2"
        shift
        ;;
    --cfg)
        shift
        for d in $($CUR_DIR/json_util dump $1 rf_driver args | sed -e 's/"//g' | tr ',' ' ') ; do
            N=$(echo "$d" | cut -d '=' -f1 | sed -e "s/dev//")
            DEVS[$N]=$(echo "$d" | cut -d '=' -f2 | cut -d '@' -f1)
        done
        ;;
    --dev)
        DEVS+=("$2")
        shift
        ;;
    *)
        echo "Bad argument: $1" >&2
        exit 2
        ;;
    esac
    shift
done

if [ "${#DEVS[@]}" != "0" ] ; then

    CMD="./sdr_util"
    for d in ${!DEVS[@]} ; do
        CMD+=" -c $d"
    done

    # Check temp
    if [ "$TEMP" != "" ] ; then
        MAX="0"
        d=""
        while read line ; do

            if [[ $line =~ Device[[:space:]]/dev/sdr ]] ; then
                d=$(echo "$line" | grep -oP "sdr\K\d+")

            elif [[ $line =~ temperature: ]] ; then

                T=$(echo "$line" | grep -oP "temperature: \K\d+");
                if [[ $T -ge $TEMP ]] ; then
                    echo "Temperature too high on /dev/sdr$d: $T°C (max=$TEMP):" >&2
                    exit 3
                fi
                if [[ $T -gt $MAX ]] ; then
                    MAX="$T"
                fi
            fi

        done < <( $CMD temp )

        echo "Max temperature found: $MAX°C"
    fi

    $CMD version | grep -v 'SDR board utilities' | sed -e '/^$/d'
fi

# Show non used devices
for N in $(find /dev -name "sdr*" | grep -oP "\K\d+" | sort -n) ; do
    dev="/dev/sdr$N"
    # Selected ?
    if [ "${DEVS[$N]}" = "" ] ; then
        echo "=== Device $dev ==="
        if [ "$OTS" = "y" ] ; then
            # Set external sync for $dev
            ./sdr_util -c $N ots_init 1>/dev/null
        fi
    fi
done

exit 0
